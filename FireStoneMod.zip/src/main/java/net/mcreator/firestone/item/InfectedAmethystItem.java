package net.mcreator.firestone.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.Entity;

import net.mcreator.firestone.procedures.InfectedAmethystKazhdyiTikVInvientarieProcedure;

public class InfectedAmethystItem extends Item {
	public InfectedAmethystItem(Item.Properties properties) {
		super(properties);
	}

	@Override
	public void inventoryTick(ItemStack itemstack, Level world, Entity entity, int slot, boolean selected) {
		super.inventoryTick(itemstack, world, entity, slot, selected);
		InfectedAmethystKazhdyiTikVInvientarieProcedure.execute(entity);
	}
}