/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.firestone.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.firestone.item.TheAmethystSwordOfTheOldGodItem;
import net.mcreator.firestone.item.InfectedAmethystItem;
import net.mcreator.firestone.item.FireStoneLogoItem;
import net.mcreator.firestone.item.BlackHoleShadowItem;
import net.mcreator.firestone.item.AmetNItem;
import net.mcreator.firestone.item.AkikoItem;
import net.mcreator.firestone.FireStoneMod;

import java.util.function.Function;

public class FireStoneModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(FireStoneMod.MODID);
	public static final DeferredItem<Item> THE_AMETHYST_SWORD_OF_THE_OLD_GOD = register("the_amethyst_sword_of_the_old_god", TheAmethystSwordOfTheOldGodItem::new);
	public static final DeferredItem<Item> FIRE_STONE_MOD = block(FireStoneModBlocks.FIRE_STONE_MOD);
	public static final DeferredItem<Item> FIRE_STONE_MOD_1 = block(FireStoneModBlocks.FIRE_STONE_MOD_1);
	public static final DeferredItem<Item> FIRE_STONE_MOD_2 = block(FireStoneModBlocks.FIRE_STONE_MOD_2);
	public static final DeferredItem<Item> FIRE_STONE_MOD_3 = block(FireStoneModBlocks.FIRE_STONE_MOD_3);
	public static final DeferredItem<Item> FIRE_STONE_MOD_4 = block(FireStoneModBlocks.FIRE_STONE_MOD_4);
	public static final DeferredItem<Item> FIRE_STONE_MOD_5 = block(FireStoneModBlocks.FIRE_STONE_MOD_5);
	public static final DeferredItem<Item> AKIKO = register("akiko", AkikoItem::new);
	public static final DeferredItem<Item> FIRE_STONE_LOGO = register("fire_stone_logo", FireStoneLogoItem::new);
	public static final DeferredItem<Item> BLACK_HOLE_SHADOW = register("black_hole_shadow", BlackHoleShadowItem::new);
	public static final DeferredItem<Item> AMET_N = register("amet_n", AmetNItem::new);
	public static final DeferredItem<Item> INFECTED_AMETHYST = register("infected_amethyst", InfectedAmethystItem::new);
	public static final DeferredItem<Item> FBRICK = block(FireStoneModBlocks.FBRICK);
	public static final DeferredItem<Item> FIDRO = block(FireStoneModBlocks.FIDRO);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}