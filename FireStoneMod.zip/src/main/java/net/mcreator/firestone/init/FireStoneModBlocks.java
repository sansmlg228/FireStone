/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.firestone.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.firestone.block.FireStoneModBlock;
import net.mcreator.firestone.block.FireStoneMod5Block;
import net.mcreator.firestone.block.FireStoneMod4Block;
import net.mcreator.firestone.block.FireStoneMod3Block;
import net.mcreator.firestone.block.FireStoneMod2Block;
import net.mcreator.firestone.block.FireStoneMod1Block;
import net.mcreator.firestone.block.FidroBlock;
import net.mcreator.firestone.block.FbrickBlock;
import net.mcreator.firestone.FireStoneMod;

import java.util.function.Function;

public class FireStoneModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(FireStoneMod.MODID);
	public static final DeferredBlock<Block> FIRE_STONE_MOD = register("fire_stone_mod", FireStoneModBlock::new);
	public static final DeferredBlock<Block> FIRE_STONE_MOD_1 = register("fire_stone_mod_1", FireStoneMod1Block::new);
	public static final DeferredBlock<Block> FIRE_STONE_MOD_2 = register("fire_stone_mod_2", FireStoneMod2Block::new);
	public static final DeferredBlock<Block> FIRE_STONE_MOD_3 = register("fire_stone_mod_3", FireStoneMod3Block::new);
	public static final DeferredBlock<Block> FIRE_STONE_MOD_4 = register("fire_stone_mod_4", FireStoneMod4Block::new);
	public static final DeferredBlock<Block> FIRE_STONE_MOD_5 = register("fire_stone_mod_5", FireStoneMod5Block::new);
	public static final DeferredBlock<Block> FBRICK = register("fbrick", FbrickBlock::new);
	public static final DeferredBlock<Block> FIDRO = register("fidro", FidroBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}