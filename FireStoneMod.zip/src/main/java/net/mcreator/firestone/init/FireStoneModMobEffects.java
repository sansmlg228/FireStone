/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.firestone.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.registries.Registries;

import net.mcreator.firestone.potion.AmethystInfectionMobEffect;
import net.mcreator.firestone.potion.AmethystInfection3MobEffect;
import net.mcreator.firestone.potion.AmethystInfection2MobEffect;
import net.mcreator.firestone.FireStoneMod;

public class FireStoneModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(Registries.MOB_EFFECT, FireStoneMod.MODID);
	public static final DeferredHolder<MobEffect, MobEffect> AMETHYST_INFECTION = REGISTRY.register("amethyst_infection", () -> new AmethystInfectionMobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> AMETHYST_INFECTION_3 = REGISTRY.register("amethyst_infection_3", () -> new AmethystInfection3MobEffect());
	public static final DeferredHolder<MobEffect, MobEffect> AMETHYST_INFECTION_2 = REGISTRY.register("amethyst_infection_2", () -> new AmethystInfection2MobEffect());
}