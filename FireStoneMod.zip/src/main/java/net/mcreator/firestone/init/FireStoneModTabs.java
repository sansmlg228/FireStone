/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.firestone.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.firestone.FireStoneMod;

public class FireStoneModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, FireStoneMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> FIRE_STONE = REGISTRY.register("fire_stone",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.fire_stone.fire_stone")).icon(() -> new ItemStack(FireStoneModItems.FIRE_STONE_LOGO.get())).displayItems((parameters, tabData) -> {
				tabData.accept(FireStoneModItems.THE_AMETHYST_SWORD_OF_THE_OLD_GOD.get());
				tabData.accept(FireStoneModItems.AKIKO.get());
				tabData.accept(FireStoneModItems.FIRE_STONE_LOGO.get());
				tabData.accept(FireStoneModItems.BLACK_HOLE_SHADOW.get());
				tabData.accept(FireStoneModItems.AMET_N.get());
				tabData.accept(FireStoneModItems.INFECTED_AMETHYST.get());
				tabData.accept(FireStoneModBlocks.FBRICK.get().asItem());
				tabData.accept(FireStoneModBlocks.FIDRO.get().asItem());
			}).build());
}