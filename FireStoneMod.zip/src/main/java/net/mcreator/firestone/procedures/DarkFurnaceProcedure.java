package net.mcreator.firestone.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;
import net.minecraft.advancements.AdvancementProgress;
import net.minecraft.advancements.AdvancementHolder;

import net.mcreator.firestone.init.FireStoneModBlocks;

public class DarkFurnaceProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double zz = 0;
		double yy = 0;
		double xx = 0;
		double Schet = 0;
		if ((world.getBlockState(BlockPos.containing(x + 1, y + 1, z + 0))).getBlock() == FireStoneModBlocks.FBRICK.get() && (world.getBlockState(BlockPos.containing(x + 1, y + 1, z + 1))).getBlock() == FireStoneModBlocks.FBRICK.get()
				&& (world.getBlockState(BlockPos.containing(x + 0, y + 1, z + 1))).getBlock() == FireStoneModBlocks.FBRICK.get() && (world.getBlockState(BlockPos.containing(x - 1, y + 1, z + 0))).getBlock() == FireStoneModBlocks.FBRICK.get()
				&& (world.getBlockState(BlockPos.containing(x - 1, y + 1, z - 1))).getBlock() == FireStoneModBlocks.FBRICK.get() && (world.getBlockState(BlockPos.containing(x + 0, y + 1, z - 1))).getBlock() == FireStoneModBlocks.FBRICK.get()
				&& (world.getBlockState(BlockPos.containing(x + 1, y + 1, z - 1))).getBlock() == FireStoneModBlocks.FBRICK.get() && (world.getBlockState(BlockPos.containing(x - 1, y + 1, z + 1))).getBlock() == FireStoneModBlocks.FBRICK.get()
				&& (world.getBlockState(BlockPos.containing(x + 0, y + 1, z + 0))).getBlock() == FireStoneModBlocks.FBRICK.get() && (world.getBlockState(BlockPos.containing(x + 1, y - 1, z + 0))).getBlock() == FireStoneModBlocks.FBRICK.get()
				&& (world.getBlockState(BlockPos.containing(x + 1, y - 1, z + 1))).getBlock() == FireStoneModBlocks.FBRICK.get() && (world.getBlockState(BlockPos.containing(x + 0, y - 1, z + 1))).getBlock() == FireStoneModBlocks.FBRICK.get()
				&& (world.getBlockState(BlockPos.containing(x - 1, y - 1, z + 0))).getBlock() == FireStoneModBlocks.FBRICK.get() && (world.getBlockState(BlockPos.containing(x - 1, y - 1, z - 1))).getBlock() == FireStoneModBlocks.FBRICK.get()
				&& (world.getBlockState(BlockPos.containing(x + 0, y - 1, z - 1))).getBlock() == FireStoneModBlocks.FBRICK.get() && (world.getBlockState(BlockPos.containing(x + 1, y - 1, z - 1))).getBlock() == FireStoneModBlocks.FBRICK.get()
				&& (world.getBlockState(BlockPos.containing(x - 1, y - 1, z + 1))).getBlock() == FireStoneModBlocks.FBRICK.get() && (world.getBlockState(BlockPos.containing(x + 0, y - 1, z + 0))).getBlock() == FireStoneModBlocks.FBRICK.get()
				&& (world.getBlockState(BlockPos.containing(x + 1, y + 0, z + 0))).getBlock() == FireStoneModBlocks.FBRICK.get() && (world.getBlockState(BlockPos.containing(x + 1, y + 0, z + 1))).getBlock() == FireStoneModBlocks.FBRICK.get()
				&& (world.getBlockState(BlockPos.containing(x + 0, y + 0, z + 1))).getBlock() == FireStoneModBlocks.FBRICK.get() && (world.getBlockState(BlockPos.containing(x - 1, y + 0, z + 0))).getBlock() == FireStoneModBlocks.FBRICK.get()
				&& (world.getBlockState(BlockPos.containing(x - 1, y + 0, z - 1))).getBlock() == FireStoneModBlocks.FBRICK.get() && (world.getBlockState(BlockPos.containing(x + 0, y + 0, z - 1))).getBlock() == FireStoneModBlocks.FBRICK.get()
				&& (world.getBlockState(BlockPos.containing(x + 1, y + 0, z - 1))).getBlock() == FireStoneModBlocks.FBRICK.get() && (world.getBlockState(BlockPos.containing(x - 1, y + 0, z + 1))).getBlock() == FireStoneModBlocks.FBRICK.get()) {
			zz = 10;
			for (int index0 = 0; index0 < 20; index0++) {
				yy = -10;
				for (int index1 = 0; index1 < 20; index1++) {
					xx = -10;
					for (int index2 = 0; index2 < 20; index2++) {
						xx = xx + 1;
					}
					yy = yy + 1;
				}
				zz = zz - 1;
			}
			if (entity instanceof ServerPlayer _player) {
				AdvancementHolder _adv = _player.server.getAdvancements().get(ResourceLocation.parse("minecraft:adventure/adventuring_time"));
				if (_adv != null) {
					AdvancementProgress _ap = _player.getAdvancements().getOrStartProgress(_adv);
					if (!_ap.isDone()) {
						for (String criteria : _ap.getRemainingCriteria())
							_player.getAdvancements().award(_adv, criteria);
					}
				}
			}
		}
	}
}