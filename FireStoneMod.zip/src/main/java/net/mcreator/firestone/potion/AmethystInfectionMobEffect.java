package net.mcreator.firestone.potion;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.core.particles.ParticleTypes;

import net.mcreator.firestone.procedures.AmethystInfectionPriNalozhieniiEffiektaProcedure;

public class AmethystInfectionMobEffect extends MobEffect {
	public AmethystInfectionMobEffect() {
		super(MobEffectCategory.HARMFUL, -6750055, mobEffectInstance -> ParticleTypes.END_ROD);
	}

	@Override
	public void onEffectStarted(LivingEntity entity, int amplifier) {
		AmethystInfectionPriNalozhieniiEffiektaProcedure.execute(entity);
	}
}